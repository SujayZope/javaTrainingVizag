package com.java.employee;

public enum Gender {
	MALE,FEMALE

}
