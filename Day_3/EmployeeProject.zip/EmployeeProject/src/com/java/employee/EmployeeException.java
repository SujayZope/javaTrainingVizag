package com.java.employee;

public class EmployeeException extends Exception {
	
	public EmployeeException(){}
	
	public EmployeeException(String error){
		super(error);
	}

}
