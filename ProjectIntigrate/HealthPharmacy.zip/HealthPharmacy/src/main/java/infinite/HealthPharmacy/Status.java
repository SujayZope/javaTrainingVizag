package infinite.HealthPharmacy;

public enum Status {
	
	PENDING,APPROVED,REJECT,REWORK

}
