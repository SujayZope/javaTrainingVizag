package infinite.HealthPharmacy;

public enum LicenceType {
	PHARMACIST,PHARMACY_TECHNICIAN,RETAIL_DRUG_STORE_PERMIT,WHOLESALE_DRUG_STORE_PERMIT

}
