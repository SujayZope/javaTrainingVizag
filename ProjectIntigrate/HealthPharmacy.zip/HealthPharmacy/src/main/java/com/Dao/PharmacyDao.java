package com.Dao;

import java.util.List;


import infinite.HealthPharmacy.Pharmacy;

public interface PharmacyDao {
	
	List<Pharmacy> getMedicalNameList();

}
