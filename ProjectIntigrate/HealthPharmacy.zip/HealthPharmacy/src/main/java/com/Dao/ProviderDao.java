package com.Dao;

import java.util.List;

import com.Medical_Entry.Provider;

public interface ProviderDao {
	
	List<Provider> getHospitalName();

}
