package com.Dao;

public interface ItemStockDao {
	
	

}
