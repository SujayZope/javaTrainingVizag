package com.Dao;

import java.util.List;

import com.Medical_Entry.Procedure;

public interface ProcedureDao {
	
	List<Procedure> getRecipientId();

}
