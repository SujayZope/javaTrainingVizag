package infinite.HealthPharmacy;

public enum Questions {
	
	FIRST_SCHOOL, MOTHER_NAME, FAVOURITE_PLACE

}
