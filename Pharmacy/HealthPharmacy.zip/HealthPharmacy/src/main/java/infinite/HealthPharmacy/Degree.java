package infinite.HealthPharmacy;

public enum Degree {
	DEPLOMA_IN_PHARMACY,BACHOLOR_IN_PHARMACY,MASTER_IN_PHARMACY

}
