package infinite.HealthPharmacy;

public enum Gender {
	
	MALE, FEMALE ,OTHER

}
